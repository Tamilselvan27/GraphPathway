export declare const getUsers: (context: any) => Promise<any>;
//# sourceMappingURL=MSGraph.d.ts.map