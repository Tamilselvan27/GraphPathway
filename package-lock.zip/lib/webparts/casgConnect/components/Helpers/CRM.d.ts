export declare function GetCustomerDetails(): Promise<void | unknown[]>;
//# sourceMappingURL=CRM.d.ts.map