/// <reference types="react" />
declare function UserDashboard(): JSX.Element;
export default UserDashboard;
//# sourceMappingURL=UserDashboard.d.ts.map