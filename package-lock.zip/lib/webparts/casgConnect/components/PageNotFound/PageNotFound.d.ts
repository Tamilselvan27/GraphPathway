/// <reference types="react" />
declare function PageNotFound(): JSX.Element;
export default PageNotFound;
//# sourceMappingURL=PageNotFound.d.ts.map