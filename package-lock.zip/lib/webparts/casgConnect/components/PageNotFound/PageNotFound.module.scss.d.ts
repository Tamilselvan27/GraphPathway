declare const styles: {
    Image: string;
};
export default styles;
//# sourceMappingURL=PageNotFound.module.scss.d.ts.map