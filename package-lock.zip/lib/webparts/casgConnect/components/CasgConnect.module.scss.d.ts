declare const styles: {
    'css-dip3t8': string;
    CanvasZone: string;
    casgConnect: string;
    teams: string;
    pageWrapper: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=CasgConnect.module.scss.d.ts.map