export interface ICasgConnectProps {
    description: string;
    isDarkTheme: boolean;
    environmentMessage: string;
    hasTeamsContext: boolean;
    userDisplayName: string;
    context: any;
}
//# sourceMappingURL=ICasgConnectProps.d.ts.map