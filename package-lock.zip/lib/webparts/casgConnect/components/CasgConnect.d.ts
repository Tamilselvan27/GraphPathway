import * as React from "react";
import type { ICasgConnectProps } from "./ICasgConnectProps";
import "bootstrap/dist/css/bootstrap.min.css";
import "primereact/resources/themes/tailwind-light/theme.css";
export declare let Envcontext: React.Context<null>;
export default class CasgConnect extends React.Component<ICasgConnectProps, {}> {
    render(): React.ReactElement<ICasgConnectProps>;
}
//# sourceMappingURL=CasgConnect.d.ts.map