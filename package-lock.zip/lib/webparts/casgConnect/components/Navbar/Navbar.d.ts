/// <reference types="react" />
declare function Navbar(): JSX.Element;
export default Navbar;
//# sourceMappingURL=Navbar.d.ts.map