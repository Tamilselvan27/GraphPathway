declare const styles: {
    navbarHeader: string;
};
export default styles;
//# sourceMappingURL=Navbar.module.scss.d.ts.map