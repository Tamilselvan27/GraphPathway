/// <reference types="react" />
import "bootstrap/dist/css/bootstrap.min.css";
export default function Routers(): JSX.Element;
//# sourceMappingURL=Routers.d.ts.map