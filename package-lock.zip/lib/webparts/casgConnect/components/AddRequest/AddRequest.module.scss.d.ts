declare const styles: {
    container_Wrapper: string;
    addContainer: string;
    header_quadraLogo: string;
    headerWrapper: string;
    AddRequest_Button: string;
    submit_Container: string;
    previewRequesterImage: string;
    previewRequesterPDF: string;
    inputfile: string;
    Attachmentwrapper: string;
    AttachmentCard: string;
};
export default styles;
//# sourceMappingURL=AddRequest.module.scss.d.ts.map