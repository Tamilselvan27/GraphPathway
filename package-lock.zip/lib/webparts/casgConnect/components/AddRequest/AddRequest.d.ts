/// <reference types="react" />
declare function AddRequest(): JSX.Element;
export default AddRequest;
//# sourceMappingURL=AddRequest.d.ts.map