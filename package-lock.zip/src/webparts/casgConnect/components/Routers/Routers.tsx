import "bootstrap/dist/css/bootstrap.min.css";
import { Route, Routes } from "react-router-dom";
import AddRequest from "../AddRequest/AddRequest";
import PageNotFound from "../PageNotFound/PageNotFound";
import * as React from "react";
import UserDashboard from "../UserDashboard/UserDashboard";
export default function Routers() {
  return (
    <Routes>
      <Route path="/" element={<UserDashboard />} />
      <Route path="/AddRequest" element={<AddRequest />} />
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
}
