import axios from "axios";
export async function GetCustomerDetails() {
  // let token = await GetAccessToken();
  // console.log('get Customer details');
  let src = await axios
    .get("https://crmbackendapi.azurewebsites.net/CustomerDetails", {
      headers: {
        "Content-Type": "application/json",
        Cookie:
          "ARRAffinity=d98b935261bd2af9f3e05965d84680564df9724e56051aa975192705b3be207c; ARRAffinitySameSite=d98b935261bd2af9f3e05965d84680564df9724e56051aa975192705b3be207c",
        "Access-cred":
          "NwgUpAE~9-8YH94~N9yju_BYHZX4M0_wU.@1583726c-83aa-4cdc-903b-2d209e6c3b60",
      },
    })
    .then((response: any) => {
      // console.log(response);
      return Array.from(
        new Set(response.data.map((res: any) => res.customerName))
      );
    })
    .catch((error: any) => {
      console.log(error);
    });

  return src;
}
