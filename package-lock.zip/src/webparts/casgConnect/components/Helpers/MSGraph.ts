import { MSGraphClient } from "@microsoft/sp-http";

let results: any = [];

const graphAPILooper = async (result: any, context: any) => {
  let val = result["@odata.nextLink"].replaceAll("skiptoken", "skipToken");
  await context.msGraphClientFactory
    .getClient()
    .then((client: MSGraphClient): any => {
      return client
        .api("/users")
        .skipToken(val.split("skipToken=")[1])
        .get()
        .then((result) => {
          console.log(result);
          if (val) {
            results.push(
              ...result.value.map((result: any) => ({
                userName: result.displayName.trim(),
                userEmailId: result.userPrincipalName.trim(),
              }))
            );
            return graphAPILooper(result, context);
          }
          return results.push(
            ...result.value.map((result: any) => ({
              userName: result.displayName.trim(),
              userEmailId: result.userPrincipalName.trim(),
            }))
          );
        })
        .catch((err) => {
          return [];
        });
    });
};

export const getUsers = async (context: any) => {
  await context.msGraphClientFactory
    .getClient()
    .then((client: MSGraphClient): any => {
      return client
        .api("/users")
        .get()
        .then((result) => {
          console.log(result);
          if (result["@odata.nextLink"]) {
            results.push(
              ...result.value.map((result: any) => ({
                userName: result.displayName.trim(),
                userEmailId: result.userPrincipalName.trim(),
              }))
            );
            return graphAPILooper(result, context);
          }

          return results.push(
            ...result.value.map((result: any) => ({
              userName: result.displayName.trim(),
              userEmailId: result.userPrincipalName.trim(),
            }))
          );
        })
        .catch((err) => {
          return [];
        });
    });
  return results;
};
