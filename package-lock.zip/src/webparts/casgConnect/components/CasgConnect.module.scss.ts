/* tslint:disable */
require("./CasgConnect.module.css");
const styles = {
  'css-dip3t8': 'css-dip3t8_10825e05',
  CanvasZone: 'CanvasZone_10825e05',
  casgConnect: 'casgConnect_10825e05',
  teams: 'teams_10825e05',
  pageWrapper: 'pageWrapper_10825e05',
  welcome: 'welcome_10825e05',
  welcomeImage: 'welcomeImage_10825e05',
  links: 'links_10825e05'
};

export default styles;
/* tslint:enable */