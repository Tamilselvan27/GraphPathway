/* tslint:disable */
require("./AddRequest.module.css");
const styles = {
  container_Wrapper: 'container_Wrapper_f33d1841',
  addContainer: 'addContainer_f33d1841',
  header_quadraLogo: 'header_quadraLogo_f33d1841',
  headerWrapper: 'headerWrapper_f33d1841',
  AddRequest_Button: 'AddRequest_Button_f33d1841',
  submit_Container: 'submit_Container_f33d1841',
  previewRequesterImage: 'previewRequesterImage_f33d1841',
  previewRequesterPDF: 'previewRequesterPDF_f33d1841',
  inputfile: 'inputfile_f33d1841',
  Attachmentwrapper: 'Attachmentwrapper_f33d1841',
  AttachmentCard: 'AttachmentCard_f33d1841'
};

export default styles;
/* tslint:enable */