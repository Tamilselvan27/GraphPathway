import * as React from "react";
import {
  Sidebar,
  Menu,
  MenuItem,
  SubMenu,
  menuClasses,
} from "react-pro-sidebar";
import { Link } from "react-router-dom";
import styles from "./Navbar.module.scss";
import { Body1Strong } from "@fluentui/react-components";
function Navbar() {
  return (
    <Sidebar width="200px" color="#fff" style={{ height: "92vh" }}>
      <div className={styles.navbarHeader}>
        <img
          src={require("../../assets/Logo_CASG_Connect.png")}
          style={{ width: "190px" }}
        />
      </div>
      <Menu
        menuItemStyles={{
          button: {
            [`&.active`]: {
              backgroundColor: "#13395e",
              color: "#b6c8d9",
            },
          },
        }}
      >
        <MenuItem
          component={<Link to="/" />}
          icon={
            <img
              src={require("../../assets/icons8-dashboard-64.png")}
              style={{ width: "24px" }}
            />
          }
        >
          <Body1Strong>Dashbaord</Body1Strong>
        </MenuItem>
        <MenuItem
          component={<Link to="/AddRequest" />}
          icon={
            <img
              src={require("../../assets/icons8-add-96.png")}
              style={{ width: "24px" }}
            />
          }
        >
          <Body1Strong>Add Request</Body1Strong>
        </MenuItem>
        <Menu
          menuItemStyles={{
            button: ({ level, active, disabled }: any) => {
              if (level === 0)
                return {
                  color: disabled ? "#000" : "#000",
                  backgroundColor: active ? "#13395e" : undefined,
                };
            },
          }}
        >
          <SubMenu
            label="Manage"
            rootStyles={{
              ["& > ." + menuClasses.button]: {
                fontWeight: 500,
                color: "#9f0099",
              },
            }}
            icon={
              <img
                src={require("../../assets/icons8-user-96.png")}
                style={{ width: "24px" }}
              />
            }
          >
            <MenuItem>
              <Body1Strong>Super Admins</Body1Strong>
            </MenuItem>
            <MenuItem>
              <Body1Strong>Leads</Body1Strong>
            </MenuItem>
          </SubMenu>
        </Menu>
      </Menu>
    </Sidebar>
  );
}

export default Navbar;
