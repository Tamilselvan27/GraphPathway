/* tslint:disable */
require("./Navbar.module.css");
const styles = {
  navbarHeader: 'navbarHeader_cb4d748c'
};

export default styles;
/* tslint:enable */