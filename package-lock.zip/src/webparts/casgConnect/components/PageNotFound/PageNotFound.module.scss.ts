/* tslint:disable */
require("./PageNotFound.module.css");
const styles = {
  Image: 'Image_ad54d416'
};

export default styles;
/* tslint:enable */