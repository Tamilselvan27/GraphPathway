import * as React from 'react'
import { Body2, Display, FluentProvider, Image, Link, Subtitle1, webLightTheme } from '@fluentui/react-components'
import styles from './PageNotFound.module.scss'
function PageNotFound() {
    return (
        <FluentProvider className="container" style={{ display: "flex", gap: 10 }} theme={webLightTheme}>
            <div className='container'>
                <div className="row d-flex align-items-center">
                    <div className="col">
                        <div className="row">
                            <Display>404</Display>
                        </div>
                        <div className="row">
                            <Subtitle1>Oops, this page does not exist.</Subtitle1>
                        </div>
                        <br />
                        <div className="row">
                            <Body2>Please <Link href={"#/ECO"}>click here</Link> to navigate to the home page!</Body2>
                        </div>
                    </div>
                    <div className="col"><Image className={styles.Image}
                        src={require('../../assets/404_NotFound.svg')}
                    /></div></div>
            </div>
        </FluentProvider>

    )
}

export default PageNotFound
